export interface Word {
  id: string;
  text: string;
  matchingKey: string;
}

export interface HomeProps {}
