import { createGlobalStyle } from "styled-components";

const GlobalStyle = createGlobalStyle`

  body {
    margin: 0;
    padding: 0;
    overscroll-behavior: contain;
  }
  #root {
    background-color: #f0f2f5;
    max-width: 450px;
    margin: 0 auto;
    min-height: 100vh;
  }
`;

export default GlobalStyle;
